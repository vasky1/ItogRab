﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace system
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            FillTable();
        }

        //Добавляет товар на основе введенных данных
        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (textBoxName.Text == "" || textBoxCount.Text == "" || textBoxPrice.Text == "") { MessageBox.Show("Заполните данные для добавления"); return; }

            string Name = textBoxName.Text;
            int Count = int.Parse(textBoxCount.Text);
            string Price = textBoxPrice.Text;

            string connectionString = @"Data Source=DESKTOP-1Q4US6J;Initial Catalog=syystem;Integrated Security=True";
            string sqlExpression = $"INSERT INTO Товары (Namee, Countt, PriceForOne) VALUES ('{Name}', {Count}, {Price})";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sqlExpression, connection);
                int number = command.ExecuteNonQuery();
            }

            FillTable();
        }

        //Удаляет выбранный товар из списка
        private void buttonDelet_Click(object sender, EventArgs e)
        {
            string id = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();

            string connectionString = @"Data Source=DESKTOP-1Q4US6J;Initial Catalog=syystem;Integrated Security=True";
            string sqlExpression = $"DELETE  FROM Товары WHERE ID = {id}";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sqlExpression, connection);
                int number = command.ExecuteNonQuery();
            }

            FillTable();
        }

        /// <summary>
        /// Обновляет гриды при выборе другой страницы
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillTable();
        }

        /// <summary>
        /// обновляет данные в датагридах из бд
        /// </summary>
        private void FillTable()
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "syystemDataSet.МониторингПокупок". При необходимости она может быть перемещена или удалена.
            this.мониторингПокупокTableAdapter.Fill(this.syystemDataSet.МониторингПокупок);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "syystemDataSet.Товары". При необходимости она может быть перемещена или удалена.
            this.товарыTableAdapter.Fill(this.syystemDataSet.Товары);
        }

        //добавляет чек
        private void buttonAddCheck_Click(object sender, EventArgs e)
        {
            if (comboBoxBuyTov.Text == "" || textBoxCountBuy.Text == "") { MessageBox.Show("Заполните данные для добавления"); return; }

            string Name = comboBoxBuyTov.Text;
            int Count = int.Parse(textBoxCountBuy.Text);
            int IdTov = comboBoxBuyTov.SelectedIndex;
            double Price = double.Parse(dataGridView1.Rows[IdTov].Cells[3].Value.ToString());
            int zaza = int.Parse(dataGridView1.Rows[IdTov].Cells[2].Value.ToString()) - Count;
            if (zaza < 0) { MessageBox.Show("Такого количества товара нет на складе!"); return; }

            int id = int.Parse(dataGridView1.Rows[IdTov].Cells[0].Value.ToString());

            string connectionString = @"Data Source=DESKTOP-1Q4US6J;Initial Catalog=syystem;Integrated Security=True";
            string sqlExpression = $"UPDATE Товары SET Countt = {zaza} WHERE ID = {id}";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sqlExpression, connection);
                int number = command.ExecuteNonQuery();
            }

             connectionString = @"Data Source=DESKTOP-1Q4US6J;Initial Catalog=syystem;Integrated Security=True";
             sqlExpression = $"INSERT INTO МониторингПокупок (Дата_Покупки, Название, [Кол-во], СтоимДляОдного) VALUES (CURRENT_TIMESTAMP, {Name}, {Count}, {Price})";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sqlExpression, connection);
                int number = command.ExecuteNonQuery();
            }

            FillTable();
        }

        //Удаляет выбранную строчку в гриде с чеками
        private void buttonDeletCheck_Click(object sender, EventArgs e)
        {
            string id = dataGridView2.SelectedRows[0].Cells[0].Value.ToString();

            string connectionString = @"Data Source=DESKTOP-1Q4US6J;Initial Catalog=syystem;Integrated Security=True";
            string sqlExpression = $"DELETE  FROM МониторингПокупок WHERE ID = {id}";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sqlExpression, connection);
                int number = command.ExecuteNonQuery();
            }

            FillTable();
        }
    }
}
