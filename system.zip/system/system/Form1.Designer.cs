﻿namespace system
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.buttonDelet = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.textBoxCount = new System.Windows.Forms.TextBox();
            this.textBoxPrice = new System.Windows.Forms.TextBox();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.товарыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPageChekCont = new System.Windows.Forms.TabPage();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.мониторингПокупокBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.buttonDeletCheck = new System.Windows.Forms.Button();
            this.buttonAddCheck = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBoxBuyTov = new System.Windows.Forms.ComboBox();
            this.товарыBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.labelCountBuy = new System.Windows.Forms.Label();
            this.textBoxCountBuy = new System.Windows.Forms.TextBox();
            this.мониторингПокупокBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.мониторингПокупокBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.syystemDataSet = new system.syystemDataSet();
            this.товарыBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.товарыTableAdapter = new system.syystemDataSetTableAdapters.ТоварыTableAdapter();
            this.мониторингПокупокBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.мониторингПокупокTableAdapter = new system.syystemDataSetTableAdapters.МониторингПокупокTableAdapter();
            this.товарыBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.стоимДляОдногоDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.товарыBindingSource)).BeginInit();
            this.tabPageChekCont.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.мониторингПокупокBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.товарыBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.мониторингПокупокBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.мониторингПокупокBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.syystemDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.товарыBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.мониторингПокупокBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.товарыBindingSource3)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPageChekCont);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1713, 779);
            this.tabControl1.TabIndex = 1;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tabPage1.Controls.Add(this.buttonDelet);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.buttonAdd);
            this.tabPage1.Controls.Add(this.textBoxCount);
            this.tabPage1.Controls.Add(this.textBoxPrice);
            this.tabPage1.Controls.Add(this.textBoxName);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1705, 750);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Контроль товаров";
            // 
            // buttonDelet
            // 
            this.buttonDelet.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonDelet.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonDelet.Location = new System.Drawing.Point(7, 622);
            this.buttonDelet.Name = "buttonDelet";
            this.buttonDelet.Size = new System.Drawing.Size(603, 122);
            this.buttonDelet.TabIndex = 8;
            this.buttonDelet.Text = "Удалить";
            this.buttonDelet.UseVisualStyleBackColor = false;
            this.buttonDelet.Click += new System.EventHandler(this.buttonDelet_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 185);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "Цена за 1 шт.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 125);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Кол-во товара";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "Название";
            // 
            // buttonAdd
            // 
            this.buttonAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.buttonAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonAdd.Location = new System.Drawing.Point(6, 252);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(604, 364);
            this.buttonAdd.TabIndex = 4;
            this.buttonAdd.Text = "Добавить";
            this.buttonAdd.UseVisualStyleBackColor = false;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // textBoxCount
            // 
            this.textBoxCount.Location = new System.Drawing.Point(7, 144);
            this.textBoxCount.Name = "textBoxCount";
            this.textBoxCount.Size = new System.Drawing.Size(603, 22);
            this.textBoxCount.TabIndex = 3;
            // 
            // textBoxPrice
            // 
            this.textBoxPrice.Location = new System.Drawing.Point(7, 204);
            this.textBoxPrice.Name = "textBoxPrice";
            this.textBoxPrice.Size = new System.Drawing.Size(603, 22);
            this.textBoxPrice.TabIndex = 2;
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(7, 79);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(603, 22);
            this.textBoxName.TabIndex = 1;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.dataGridView1.DataSource = this.товарыBindingSource2;
            this.dataGridView1.Location = new System.Drawing.Point(616, 6);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1083, 738);
            this.dataGridView1.TabIndex = 0;
            // 
            // tabPageChekCont
            // 
            this.tabPageChekCont.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tabPageChekCont.Controls.Add(this.dataGridView2);
            this.tabPageChekCont.Controls.Add(this.buttonDeletCheck);
            this.tabPageChekCont.Controls.Add(this.buttonAddCheck);
            this.tabPageChekCont.Controls.Add(this.label4);
            this.tabPageChekCont.Controls.Add(this.comboBoxBuyTov);
            this.tabPageChekCont.Controls.Add(this.labelCountBuy);
            this.tabPageChekCont.Controls.Add(this.textBoxCountBuy);
            this.tabPageChekCont.Location = new System.Drawing.Point(4, 25);
            this.tabPageChekCont.Name = "tabPageChekCont";
            this.tabPageChekCont.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageChekCont.Size = new System.Drawing.Size(1705, 750);
            this.tabPageChekCont.TabIndex = 1;
            this.tabPageChekCont.Text = "Чеки";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.названиеDataGridViewTextBoxColumn,
            this.dataGridViewTextBoxColumn8,
            this.стоимДляОдногоDataGridViewTextBoxColumn,
            this.dataGridViewTextBoxColumn9});
            this.dataGridView2.DataSource = this.мониторингПокупокBindingSource3;
            this.dataGridView2.Location = new System.Drawing.Point(612, 6);
            this.dataGridView2.MultiSelect = false;
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(1087, 741);
            this.dataGridView2.TabIndex = 17;
            // 
            // buttonDeletCheck
            // 
            this.buttonDeletCheck.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonDeletCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonDeletCheck.Location = new System.Drawing.Point(7, 223);
            this.buttonDeletCheck.Name = "buttonDeletCheck";
            this.buttonDeletCheck.Size = new System.Drawing.Size(603, 122);
            this.buttonDeletCheck.TabIndex = 16;
            this.buttonDeletCheck.Text = "Удалить";
            this.buttonDeletCheck.UseVisualStyleBackColor = false;
            this.buttonDeletCheck.Click += new System.EventHandler(this.buttonDeletCheck_Click);
            // 
            // buttonAddCheck
            // 
            this.buttonAddCheck.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.buttonAddCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonAddCheck.Location = new System.Drawing.Point(6, 351);
            this.buttonAddCheck.Name = "buttonAddCheck";
            this.buttonAddCheck.Size = new System.Drawing.Size(604, 393);
            this.buttonAddCheck.TabIndex = 15;
            this.buttonAddCheck.Text = "Добавить";
            this.buttonAddCheck.UseVisualStyleBackColor = false;
            this.buttonAddCheck.Click += new System.EventHandler(this.buttonAddCheck_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 130);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 16);
            this.label4.TabIndex = 14;
            this.label4.Text = "Купленный товар";
            // 
            // comboBoxBuyTov
            // 
            this.comboBoxBuyTov.DataSource = this.товарыBindingSource3;
            this.comboBoxBuyTov.DisplayMember = "Namee";
            this.comboBoxBuyTov.FormattingEnabled = true;
            this.comboBoxBuyTov.Location = new System.Drawing.Point(3, 149);
            this.comboBoxBuyTov.Name = "comboBoxBuyTov";
            this.comboBoxBuyTov.Size = new System.Drawing.Size(603, 24);
            this.comboBoxBuyTov.TabIndex = 13;
            this.comboBoxBuyTov.ValueMember = "ID";
            // 
            // labelCountBuy
            // 
            this.labelCountBuy.AutoSize = true;
            this.labelCountBuy.Location = new System.Drawing.Point(3, 86);
            this.labelCountBuy.Name = "labelCountBuy";
            this.labelCountBuy.Size = new System.Drawing.Size(181, 16);
            this.labelCountBuy.TabIndex = 12;
            this.labelCountBuy.Text = "Кол-во купленного товара";
            // 
            // textBoxCountBuy
            // 
            this.textBoxCountBuy.Location = new System.Drawing.Point(3, 105);
            this.textBoxCountBuy.Name = "textBoxCountBuy";
            this.textBoxCountBuy.Size = new System.Drawing.Size(603, 22);
            this.textBoxCountBuy.TabIndex = 10;
            // 
            // syystemDataSet
            // 
            this.syystemDataSet.DataSetName = "syystemDataSet";
            this.syystemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // товарыBindingSource2
            // 
            this.товарыBindingSource2.DataMember = "Товары";
            this.товарыBindingSource2.DataSource = this.syystemDataSet;
            // 
            // товарыTableAdapter
            // 
            this.товарыTableAdapter.ClearBeforeFill = true;
            // 
            // мониторингПокупокBindingSource3
            // 
            this.мониторингПокупокBindingSource3.DataMember = "МониторингПокупок";
            this.мониторингПокупокBindingSource3.DataSource = this.syystemDataSet;
            // 
            // мониторингПокупокTableAdapter
            // 
            this.мониторингПокупокTableAdapter.ClearBeforeFill = true;
            // 
            // товарыBindingSource3
            // 
            this.товарыBindingSource3.DataMember = "Товары";
            this.товарыBindingSource3.DataSource = this.syystemDataSet;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ID";
            this.dataGridViewTextBoxColumn1.HeaderText = "ID";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Namee";
            this.dataGridViewTextBoxColumn2.HeaderText = "Название";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Countt";
            this.dataGridViewTextBoxColumn3.HeaderText = "Кол-во";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "PriceForOne";
            this.dataGridViewTextBoxColumn4.HeaderText = "Цена за 1шт.";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "PriceAll";
            this.dataGridViewTextBoxColumn5.HeaderText = "Цена общая";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "ID";
            this.dataGridViewTextBoxColumn6.HeaderText = "ID";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 125;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Дата_Покупки";
            this.dataGridViewTextBoxColumn7.HeaderText = "Дата покупки";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 125;
            // 
            // названиеDataGridViewTextBoxColumn
            // 
            this.названиеDataGridViewTextBoxColumn.DataPropertyName = "Название";
            this.названиеDataGridViewTextBoxColumn.HeaderText = "Название";
            this.названиеDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.названиеDataGridViewTextBoxColumn.Name = "названиеDataGridViewTextBoxColumn";
            this.названиеDataGridViewTextBoxColumn.ReadOnly = true;
            this.названиеDataGridViewTextBoxColumn.Width = 125;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Кол-во";
            this.dataGridViewTextBoxColumn8.HeaderText = "Кол-во";
            this.dataGridViewTextBoxColumn8.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Width = 125;
            // 
            // стоимДляОдногоDataGridViewTextBoxColumn
            // 
            this.стоимДляОдногоDataGridViewTextBoxColumn.DataPropertyName = "СтоимДляОдного";
            this.стоимДляОдногоDataGridViewTextBoxColumn.HeaderText = "Цена за 1шт.";
            this.стоимДляОдногоDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.стоимДляОдногоDataGridViewTextBoxColumn.Name = "стоимДляОдногоDataGridViewTextBoxColumn";
            this.стоимДляОдногоDataGridViewTextBoxColumn.ReadOnly = true;
            this.стоимДляОдногоDataGridViewTextBoxColumn.Width = 125;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "ОбщаяСуммаТовара";
            this.dataGridViewTextBoxColumn9.HeaderText = "Цена общая";
            this.dataGridViewTextBoxColumn9.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Width = 125;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1737, 803);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Система учета товаров";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.товарыBindingSource)).EndInit();
            this.tabPageChekCont.ResumeLayout(false);
            this.tabPageChekCont.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.мониторингПокупокBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.товарыBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.мониторингПокупокBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.мониторингПокупокBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.syystemDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.товарыBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.мониторингПокупокBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.товарыBindingSource3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPageChekCont;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource товарыBindingSource;
        private System.Windows.Forms.BindingSource мониторингПокупокBindingSource;
        private System.Windows.Forms.Button buttonDelet;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.TextBox textBoxCount;
        private System.Windows.Forms.TextBox textBoxPrice;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn counttDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceForOneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceAllDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource товарыBindingSource1;
        private System.Windows.Forms.Label labelCountBuy;
        private System.Windows.Forms.TextBox textBoxCountBuy;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBoxBuyTov;
        private System.Windows.Forms.Button buttonAddCheck;
        private System.Windows.Forms.Button buttonDeletCheck;
        private System.Windows.Forms.BindingSource мониторингПокупокBindingSource1;
        private System.Windows.Forms.BindingSource мониторингПокупокBindingSource2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаПокупкиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDТовараDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn колвоDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idСтоимостьДляОдногоDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn общаяСуммаТовараDataGridViewTextBoxColumn;
        private syystemDataSet syystemDataSet;
        private System.Windows.Forms.BindingSource товарыBindingSource2;
        private syystemDataSetTableAdapters.ТоварыTableAdapter товарыTableAdapter;
        private System.Windows.Forms.BindingSource мониторингПокупокBindingSource3;
        private syystemDataSetTableAdapters.МониторингПокупокTableAdapter мониторингПокупокTableAdapter;
        private System.Windows.Forms.BindingSource товарыBindingSource3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn стоимДляОдногоDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
    }
}

